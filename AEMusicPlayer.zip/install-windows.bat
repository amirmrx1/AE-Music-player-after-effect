@echo off
chcp 65001 >nul
setlocal
set "DEST=%APPDATA%\Adobe\CEP\extensions\MusicDucker"

echo.
echo  === AE Music Player installer ===
echo.

if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
xcopy /e /i /y "%~dp0MusicDucker\*" "%DEST%\" >nul

rem Allow unsigned CEP panels (CSXS 9 - 13 covers AE 2019 and newer)
for %%V in (9 10 11 12 13) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

echo  Installed to:
echo  %DEST%
echo.
echo  Now restart After Effects, then open:
echo  Window ^> Extensions ^> AE Music Player
echo.
pause
