(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const KEY = 'musicDucker.v2';
  const OLD_KEY = 'musicDucker.v1';
  const AUDIO_RE = /\.(mp3|wav|m4a|aac|ogg|oga|flac|opus)$/i;

  /* ---------- translations ---------- */
  const I18N = {
    fa: {
      pickTrack: 'یه آهنگ انتخاب کن', noFolder: 'پوشه‌ای انتخاب نشده', folderBtn: '📁 پوشه', rescan: 'اسکن دوباره',
      search: 'جستجو تو آهنگ‌ها...', favOnly: '★ فقط مورد علاقه',
      emptyTitle: 'پوشه آهنگ‌هات رو انتخاب کن', emptyHint: 'یا پوشه رو بکش بنداز رو همین پنل',
      tracks: '{n} آهنگ', tracksOf: '{n} از {m} آهنگ',
      fav: 'علاقه‌مندی', shuffle: 'شافل', prev: 'قبلی', play: 'پخش / توقف', next: 'بعدی', loop: 'تکرار همین آهنگ',
      duckTitle: 'دَک خودکار', duckSub: 'وقتی از افترافکت صدا میاد، موزیک کم میشه',
      duckLevel: 'صدای موزیک موقع پلی‌بک', holdOn: '🔇 دَک دستی', holdOff: '🔊 آزاد کن', adv: '⚙ تنظیمات بیشتر',
      attack: 'سرعت کم شدن صدا', release: 'سرعت برگشتن صدا', holdDelay: 'صبر قبل از برگشتن', sens: 'حساسیت به صدای AE',
      lvlTip: 'سطح صدای خروجی افترافکت',
      pReady: 'آماده', pDuck: 'صدا کم شد', pOff: 'دَک خاموشه', pInit: 'در حال راه‌اندازی...',
      pErr: 'خطا تو تشخیص صدا', pWin: 'دَک خودکار: فقط ویندوز',
      lInit: 'در حال راه‌اندازی...', lWait: 'منتظر صدای افترافکت...', lHot: 'صدای افترافکت شناسایی شد',
      lQuiet: 'صدایی از افترافکت نمیاد', lNoNode: 'نود فعال نیست (فقط دَک دستی)',
      lNotWin: 'تشخیص خودکار فقط ویندوز — دَک دستی هست',
      eCompile: 'خطای راه‌اندازی:', eGeneric: 'خطا:', eNoPs: 'پاورشل پیدا نشد', eSpawn: 'پاورشل اجرا نشد',
      eStopped: 'تشخیص صدا متوقف شد',
      tNoTracks: 'تو این پوشه آهنگی پیدا نشد', tDialog: 'دیالوگ باز نشد — پوشه رو بکش بنداز رو پنل',
      tPickFirst: 'اول پوشه آهنگ رو انتخاب کن', tSkip: 'این فایل پخش نشد، رد میشم', tUpdated: 'لیست آپدیت شد',
      tDrop: 'برای درگ‌ودراپ دسترسی نود لازمه — از دکمه پوشه استفاده کن', tMeterFail: 'تشخیص صدا راه نیفتاد',
      dialogTitle: 'پوشه آهنگ‌ها رو انتخاب کن',
      langTip: 'زبان / Language', thPurple: 'بنفش', thBlue: 'آبی', thMono: 'مشکی سفید'
    },
    en: {
      pickTrack: 'Pick a track', noFolder: 'No folder selected', folderBtn: '📁 Folder', rescan: 'Rescan',
      search: 'Search tracks...', favOnly: '★ Favorites only',
      emptyTitle: 'Choose your music folder', emptyHint: 'or drag a folder onto this panel',
      tracks: '{n} tracks', tracksOf: '{n} of {m} tracks',
      fav: 'Favorite', shuffle: 'Shuffle', prev: 'Previous', play: 'Play / Pause', next: 'Next', loop: 'Repeat this track',
      duckTitle: 'Auto Duck', duckSub: 'Music gets quieter when After Effects makes sound',
      duckLevel: 'Music volume during playback', holdOn: '🔇 Manual duck', holdOff: '🔊 Release', adv: '⚙ More settings',
      attack: 'Duck speed (fade out)', release: 'Recover speed (fade in)', holdDelay: 'Wait before recovering', sens: 'AE audio sensitivity',
      lvlTip: 'After Effects output level',
      pReady: 'Ready', pDuck: 'Ducking', pOff: 'Duck is off', pInit: 'Starting...',
      pErr: 'Audio detection error', pWin: 'Auto duck: Windows only',
      lInit: 'Starting...', lWait: 'Waiting for After Effects audio...', lHot: 'After Effects audio detected',
      lQuiet: 'No audio from After Effects', lNoNode: 'Node is disabled (manual duck only)',
      lNotWin: 'Auto detection is Windows-only — manual duck works',
      eCompile: 'Startup error:', eGeneric: 'Error:', eNoPs: 'PowerShell not found', eSpawn: 'Could not run PowerShell',
      eStopped: 'Audio detection stopped',
      tNoTracks: 'No tracks found in this folder', tDialog: 'Dialog failed — drag a folder onto the panel',
      tPickFirst: 'Choose a music folder first', tSkip: "Couldn't play this file, skipping", tUpdated: 'List updated',
      tDrop: 'Drag & drop needs Node access — use the Folder button', tMeterFail: 'Audio detection failed to start',
      dialogTitle: 'Choose your music folder',
      langTip: 'Language / زبان', thPurple: 'Purple', thBlue: 'Blue', thMono: 'Black & White'
    }
  };

  /* ---------- settings ---------- */
  const S = {
    lang: 'fa', theme: 'purple',
    vol: 70, duckOn: true, duckLevel: 15, attack: 150, release: 700, hold: 700,
    sens: 60, folder: '', last: '', shuffle: false, loop: false,
    favOnly: false, favs: [], advOpen: false
  };
  try {
    const old = JSON.parse(localStorage.getItem(OLD_KEY) || '{}');
    delete old.hold; delete old.mode;
    Object.assign(S, old, JSON.parse(localStorage.getItem(KEY) || '{}'));
  } catch (e) {}
  if (!I18N[S.lang]) S.lang = 'fa';
  if (['purple', 'blue', 'mono'].indexOf(S.theme) < 0) S.theme = 'purple';
  const favs = new Set(S.favs);
  const save = () => {
    S.favs = Array.from(favs);
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {}
  };

  const t = (k, vars) => {
    let s = (I18N[S.lang] && I18N[S.lang][k]) || I18N.en[k] || k;
    if (vars) Object.keys(vars).forEach((v) => { s = s.replace('{' + v + '}', vars[v]); });
    return s;
  };

  /* ---------- helpers ---------- */
  const clamp = (v, a, b) => Math.min(b === undefined ? 1 : b, Math.max(a === undefined ? 0 : a, v));
  const base = (p) => p.split(/[\\/]/).pop();
  const noExt = (n) => n.replace(/\.[^.]+$/, '');
  const fmt = (s) => {
    if (!isFinite(s)) return '0:00';
    s = Math.floor(s);
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  };
  const toUrl = (p) => {
    p = p.replace(/\\/g, '/');
    if (p[0] !== '/') p = '/' + p;
    return 'file://' + encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F');
  };
  const paint = (el) => {
    const min = +el.min || 0, max = +el.max || 100;
    el.style.setProperty('--p', ((el.value - min) / (max - min)) * 100 + '%');
  };
  let toastTimer = 0;
  const toast = (msg) => {
    const el = $('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
  };

  /* ---------- file system ---------- */
  let nodeFs = null, nodePath = null;
  try { if (window.require) { nodeFs = window.require('fs'); nodePath = window.require('path'); } } catch (e) {}

  const natCmp = (a, b) => base(a).localeCompare(base(b), undefined, { numeric: true, sensitivity: 'base' });

  function scan(dir) {
    const out = [];
    if (nodeFs && nodePath) {
      const walk = (d, depth) => {
        let names;
        try { names = nodeFs.readdirSync(d); } catch (e) { return; }
        names.forEach((n) => {
          const p = nodePath.join(d, n);
          if (AUDIO_RE.test(n)) { out.push(p); return; }
          if (depth < 3 && n[0] !== '.') {
            try { if (nodeFs.statSync(p).isDirectory()) walk(p, depth + 1); } catch (e) {}
          }
        });
      };
      walk(dir, 0);
    } else if (window.cep && window.cep.fs) {
      const r = window.cep.fs.readdir(dir);
      if (!r.err) r.data.forEach((n) => { if (AUDIO_RE.test(n)) out.push(dir.replace(/[\\/]$/, '') + '/' + n); });
    }
    return out.sort(natCmp);
  }

  /* ---------- library state ---------- */
  let tracks = [];       // {path, name}
  let view = [];         // indexes into tracks (after filter)
  let cur = -1;

  function refreshFolder() {
    const el = $('folderName');
    el.textContent = S.folder ? (base(S.folder) || S.folder) : t('noFolder');
    el.title = S.folder || '';
  }

  function load(keepCurrent) {
    refreshFolder();
    if (!S.folder) { tracks = []; renderList(); return; }
    tracks = scan(S.folder).map((p) => ({ path: p, name: noExt(base(p)) }));
    cur = tracks.findIndex((tr) => tr.path === S.last);
    if (!keepCurrent && cur >= 0) { audio.src = toUrl(tracks[cur].path); }
    renderList();
    updateNow();
    if (!tracks.length) toast(t('tNoTracks'));
  }

  function setFolder(p) {
    S.folder = p; S.last = ''; cur = -1; audio.pause(); audio.removeAttribute('src');
    save(); load(false);
  }

  function pickFolder() {
    try {
      const r = window.cep.fs.showOpenDialogEx(false, true, t('dialogTitle'), S.folder || '', []);
      if (r && !r.err && r.data && r.data[0]) setFolder(r.data[0]);
    } catch (e) {
      toast(t('tDialog'));
    }
  }

  function renderList() {
    const q = $('search').value.trim().toLowerCase();
    view = [];
    tracks.forEach((tr, i) => {
      if (S.favOnly && !favs.has(tr.path)) return;
      if (q && tr.name.toLowerCase().indexOf(q) < 0) return;
      view.push(i);
    });
    const ul = $('list');
    const frag = document.createDocumentFragment();
    view.forEach((i, n) => {
      const li = document.createElement('li');
      li.dataset.i = i;
      if (i === cur) li.className = 'cur';
      li.innerHTML = '<span class="n"></span><span class="t" dir="auto"></span><button class="st" data-fav="1">★</button>';
      li.children[0].textContent = i === cur && !audio.paused ? '♪' : n + 1;
      li.children[1].textContent = tracks[i].name;
      li.children[1].title = tracks[i].name;
      if (favs.has(tracks[i].path)) li.children[2].classList.add('on');
      frag.appendChild(li);
    });
    ul.innerHTML = '';
    ul.appendChild(frag);
    $('empty').style.display = tracks.length ? 'none' : '';
    $('count').textContent = tracks.length
      ? (view.length === tracks.length ? t('tracks', { n: tracks.length }) : t('tracksOf', { n: view.length, m: tracks.length }))
      : '';
  }

  function markPlaying() {
    const lis = $('list').children;
    for (let k = 0; k < lis.length; k++) {
      const li = lis[k], i = +li.dataset.i;
      li.classList.toggle('cur', i === cur);
      li.children[0].textContent = i === cur && !audio.paused ? '♪' : k + 1;
    }
  }

  /* ---------- player ---------- */
  const audio = new Audio();
  audio.preload = 'metadata';
  let errStreak = 0;

  function updateNow() {
    const tr = cur >= 0 ? tracks[cur] : null;
    $('title').textContent = tr ? tr.name : t('pickTrack');
    $('sub').textContent = tr ? base(tr.path).split('.').pop().toUpperCase() + ' · ' + (cur + 1) + ' / ' + tracks.length : '—';
    $('btnFav').classList.toggle('on', !!tr && favs.has(tr.path));
    $('btnFav').textContent = tr && favs.has(tr.path) ? '★' : '☆';
    if ('mediaSession' in navigator && tr) {
      try { navigator.mediaSession.metadata = new window.MediaMetadata({ title: tr.name, artist: 'AE Music Player' }); } catch (e) {}
    }
  }

  function playIndex(i) {
    if (i < 0 || i >= tracks.length) return;
    cur = i;
    S.last = tracks[i].path; save();
    audio.src = toUrl(tracks[i].path);
    const p = audio.play();
    if (p && p.catch) p.catch(() => {});
    updateNow(); markPlaying();
  }

  function toggle() {
    if (cur < 0) {
      if (!view.length) { toast(t('tPickFirst')); return; }
      playIndex(view[0]); return;
    }
    if (audio.paused) { const p = audio.play(); if (p && p.catch) p.catch(() => {}); } else audio.pause();
  }

  function step(dir) {
    if (!view.length) return;
    let next;
    if (S.shuffle && view.length > 1) {
      do { next = view[Math.floor(Math.random() * view.length)]; } while (next === cur);
    } else {
      let pos = view.indexOf(cur);
      pos = pos < 0 ? 0 : (pos + dir + view.length) % view.length;
      next = view[pos];
    }
    playIndex(next);
  }

  audio.addEventListener('play', () => { $('btnPlay').textContent = '⏸'; $('eq').classList.add('on'); markPlaying(); errStreak = 0; });
  audio.addEventListener('pause', () => { $('btnPlay').textContent = '▶'; $('eq').classList.remove('on'); markPlaying(); });
  audio.addEventListener('ended', () => step(1));
  audio.addEventListener('loadedmetadata', () => { $('tDur').textContent = fmt(audio.duration); });
  audio.addEventListener('error', () => {
    if (cur < 0) return;
    toast(t('tSkip'));
    if (++errStreak < Math.max(3, Math.min(tracks.length, 8))) setTimeout(() => step(1), 500);
  });

  let seeking = false;
  audio.addEventListener('timeupdate', () => {
    $('tCur').textContent = fmt(audio.currentTime);
    if (!seeking && audio.duration) {
      $('seek').value = (audio.currentTime / audio.duration) * 1000;
      paint($('seek'));
    }
  });
  $('seek').addEventListener('input', () => { seeking = true; paint($('seek')); if (audio.duration) $('tCur').textContent = fmt(($('seek').value / 1000) * audio.duration); });
  $('seek').addEventListener('change', () => { if (audio.duration) audio.currentTime = ($('seek').value / 1000) * audio.duration; seeking = false; });

  /* ---------- volume + ducking ---------- */
  let autoDuck = false, holdManual = false;
  let meterState = 'init'; // init | ready | error | unsupported
  let lvlKey = 'lInit', lvlExtra = '';
  let gain = S.vol / 100, fade = null, fadeTimer = 0;

  const isDucked = () => holdManual || (S.duckOn && autoDuck);
  const targetGain = () => (isDucked() ? (S.vol / 100) * (S.duckLevel / 100) : S.vol / 100);

  function fadeStep() {
    if (!fade) { clearInterval(fadeTimer); fadeTimer = 0; return; }
    const k = clamp((performance.now() - fade.t0) / Math.max(1, fade.dur));
    const e = fade.to < fade.from ? 1 - Math.pow(1 - k, 2) : k * k * (3 - 2 * k);
    gain = fade.from + (fade.to - fade.from) * e;
    audio.volume = clamp(gain);
    if (k >= 1) { fade = null; clearInterval(fadeTimer); fadeTimer = 0; }
  }

  function retarget() {
    const to = targetGain();
    if (Math.abs(to - gain) < 0.001) { fade = null; return; }
    fade = { from: gain, to: to, t0: performance.now(), dur: to < gain ? S.attack : S.release };
    if (!fadeTimer) fadeTimer = setInterval(fadeStep, 16);
    updatePill();
  }

  function updatePill() {
    let cls = 'ok', key = 'pReady';
    if (meterState === 'unsupported') { cls = ''; key = 'pWin'; }
    else if (meterState === 'error') { cls = ''; key = 'pErr'; }
    else if (meterState === 'init') { cls = ''; key = 'pInit'; }
    else if (!S.duckOn && !holdManual) { cls = ''; key = 'pOff'; }
    if (isDucked()) { cls = 'duck'; key = 'pDuck'; }
    $('pill').className = 'pill ' + cls;
    $('pill').textContent = t(key);
    $('eq').classList.toggle('duck', isDucked());
  }

  function setAuto(v) {
    if (v === autoDuck) return;
    autoDuck = v;
    retarget(); updatePill();
  }

  function setLvl(key, extra) {
    lvlKey = key; lvlExtra = extra || '';
    const txt = t(key) + (lvlExtra ? ' ' + lvlExtra : '');
    if ($('lvlTxt').textContent !== txt) $('lvlTxt').textContent = txt;
  }

  function updateHoldBtn() {
    $('btnHold').textContent = t(holdManual ? 'holdOff' : 'holdOn');
  }

  /* ---------- After Effects audio detection (Windows) ----------
     A small PowerShell helper reads the Windows mixer peak level of AfterFX.exe.
     Nothing is sent to After Effects, so playback is never interrupted. */
  const thrOf = () => 0.02 * Math.pow(1 - S.sens / 100, 2) + 0.0005;
  const dbPct = (v) => clamp((20 * Math.log10(Math.max(v, 1e-5)) + 60) / 60);
  const placeThr = () => { $('thrMark').style.left = dbPct(thrOf()) * 100 + '%'; };
  let lastActive = -1e9;

  function onPeak(peak) {
    const now = performance.now();
    const hot = peak > thrOf();
    $('lvl').style.width = dbPct(peak) * 100 + '%';
    $('lvl').parentNode.classList.toggle('hot', hot);
    if (hot) lastActive = now;
    setLvl(hot ? 'lHot' : 'lQuiet');
    setAuto(S.duckOn && now - lastActive < S.hold);
  }

  function extDir() {
    try {
      if (window.__adobe_cep__ && window.__adobe_cep__.getSystemPath) {
        const u = window.__adobe_cep__.getSystemPath('extension');
        if (u) return decodeURI(u).replace(/^file:\/\/\//, '').replace(/\\/g, '/');
      }
    } catch (e) {}
    try { if (typeof __dirname === 'string') return __dirname.replace(/\\/g, '/'); } catch (e) {}
    return decodeURI(location.pathname.replace(/^\//, '')).replace(/\/index\.html$/, '');
  }

  let meterProc = null, restarts = 0, errCount = 0;

  function killMeter() {
    if (meterProc) { try { meterProc.kill(); } catch (e) {} meterProc = null; }
  }

  function failMeter(key, extra) {
    meterState = 'error';
    setLvl(key, extra);
    setAuto(false); updatePill();
  }

  function handleLine(line) {
    if (!line) return;
    const tag = line[0], rest = line.slice(2);
    if (tag === 'P') {
      if (meterState !== 'ready') { meterState = 'ready'; restarts = 0; updatePill(); }
      errCount = 0;
      onPeak(parseFloat(rest) || 0);
    } else if (tag === 'R') {
      meterState = 'ready'; updatePill(); setLvl('lWait');
    } else if (tag === 'E') {
      if (rest.indexOf('compile') === 0) { failMeter('eCompile', rest.slice(8, 88)); toast(t('tMeterFail')); }
      else if (++errCount > 20) failMeter('eGeneric', rest.slice(0, 80));
    }
  }

  function startMeter() {
    let os = null, cp = null;
    try { os = window.require('os'); cp = window.require('child_process'); } catch (e) {}
    if (!cp || !os) { meterState = 'unsupported'; setLvl('lNoNode'); updatePill(); return; }
    if (os.platform() !== 'win32') { meterState = 'unsupported'; setLvl('lNotWin'); updatePill(); return; }

    killMeter();
    meterState = 'init'; updatePill(); setLvl('lInit');
    const script = extDir() + '/bin/audio-meter.ps1';
    const pid = (window.process && window.process.pid) || 0;
    let proc;
    try {
      proc = cp.spawn('powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-ParentPid', String(pid)],
        { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) { failMeter('eSpawn'); return; }
    meterProc = proc;

    let buf = '', errBuf = '';
    proc.stdout.on('data', (d) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); handleLine(line); }
    });
    proc.stderr.on('data', (d) => { errBuf += d.toString(); });
    proc.on('error', () => failMeter('eNoPs'));
    proc.on('exit', () => {
      if (meterProc !== proc) return;
      meterProc = null;
      if (meterState === 'error') return;
      if (restarts++ < 3) setTimeout(startMeter, 1500);
      else failMeter('eStopped', errBuf.trim().slice(0, 60));
    });
  }
  window.addEventListener('beforeunload', killMeter);
  window.addEventListener('unload', killMeter);

  /* ---------- language + theme ---------- */
  function applyLang() {
    const L = S.lang;
    document.documentElement.lang = L;
    document.documentElement.dir = L === 'fa' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.getAttribute('data-i18n')); });
    document.querySelectorAll('[data-i18n-title]').forEach((el) => { el.title = t(el.getAttribute('data-i18n-title')); });
    document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.getAttribute('data-i18n-ph')); });
    $('btnLang').textContent = L === 'fa' ? 'EN' : 'فا';
    refreshFolder(); renderList(); updateNow(); updatePill(); updateHoldBtn(); setLvl(lvlKey, lvlExtra);
  }

  function applyTheme() {
    document.documentElement.setAttribute('data-theme', S.theme);
    document.querySelectorAll('.dot').forEach((d) => d.classList.toggle('on', d.dataset.theme === S.theme));
  }

  $('btnLang').addEventListener('click', () => { S.lang = S.lang === 'fa' ? 'en' : 'fa'; save(); applyLang(); });
  $('themes').addEventListener('click', (e) => {
    const d = e.target.closest('.dot'); if (!d) return;
    S.theme = d.dataset.theme; save(); applyTheme();
  });

  /* ---------- UI wiring ---------- */
  $('btnPlay').addEventListener('click', toggle);
  $('btnNext').addEventListener('click', () => step(1));
  $('btnPrev').addEventListener('click', () => { if (audio.currentTime > 3) audio.currentTime = 0; else step(-1); });

  const setToggle = (id, key, onChange) => {
    const b = $(id);
    b.classList.toggle('on', !!S[key]);
    b.addEventListener('click', () => { S[key] = !S[key]; b.classList.toggle('on', S[key]); save(); if (onChange) onChange(); });
  };
  setToggle('btnShuffle', 'shuffle');
  setToggle('btnLoop', 'loop', () => { audio.loop = S.loop; });
  setToggle('btnFavOnly', 'favOnly', renderList);
  audio.loop = !!S.loop;

  $('btnFav').addEventListener('click', () => {
    if (cur < 0) return;
    const p = tracks[cur].path;
    favs.has(p) ? favs.delete(p) : favs.add(p);
    save(); updateNow(); renderList();
  });

  $('list').addEventListener('click', (e) => {
    const li = e.target.closest('li'); if (!li) return;
    const i = +li.dataset.i;
    if (e.target.dataset.fav) {
      const p = tracks[i].path;
      favs.has(p) ? favs.delete(p) : favs.add(p);
      save(); updateNow(); renderList();
      return;
    }
    if (i === cur) toggle(); else playIndex(i);
  });

  $('search').addEventListener('input', renderList);
  $('btnFolder').addEventListener('click', pickFolder);
  $('btnRescan').addEventListener('click', () => { load(true); toast(t('tUpdated')); });

  // volume
  const vol = $('vol');
  vol.value = S.vol; $('volVal').textContent = S.vol + '%'; paint(vol);
  vol.addEventListener('input', () => {
    S.vol = +vol.value; $('volVal').textContent = S.vol + '%'; paint(vol); save();
    if (isDucked()) retarget(); else { fade = null; gain = S.vol / 100; audio.volume = clamp(gain); }
  });
  audio.volume = clamp(gain);

  // duck settings
  [['duckLevel', '%'], ['attack', 'ms'], ['release', 'ms'], ['hold', 'ms']].forEach((a) => {
    const id = a[0], suf = a[1], el = $(id);
    el.value = S[id]; $(id + 'Val').textContent = S[id] + suf; paint(el);
    el.addEventListener('input', () => {
      S[id] = +el.value; $(id + 'Val').textContent = el.value + suf; paint(el); save();
      if (id === 'duckLevel') retarget();
    });
  });

  $('duckOn').checked = !!S.duckOn;
  $('duckOn').addEventListener('change', () => { S.duckOn = $('duckOn').checked; save(); if (!S.duckOn) setAuto(false); retarget(); updatePill(); });

  const sens = $('sens');
  sens.value = S.sens; $('sensVal').textContent = S.sens; paint(sens); placeThr();
  sens.addEventListener('input', () => { S.sens = +sens.value; $('sensVal').textContent = S.sens; paint(sens); save(); placeThr(); });

  $('btnHold').addEventListener('click', () => {
    holdManual = !holdManual;
    $('btnHold').classList.toggle('on', holdManual);
    updateHoldBtn();
    retarget(); updatePill();
  });

  $('adv').classList.toggle('hidden', !S.advOpen);
  $('btnAdv').addEventListener('click', () => { S.advOpen = !S.advOpen; $('adv').classList.toggle('hidden', !S.advOpen); save(); });

  paint($('seek'));

  // drag & drop a folder (or a file -> its folder)
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => {
    e.preventDefault();
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f || !f.path) { toast(t('tDrop')); return; }
    let dir = f.path;
    try { if (nodeFs && !nodeFs.statSync(dir).isDirectory()) dir = nodePath.dirname(dir); } catch (err) {}
    setFolder(dir);
  });

  // media keys (if the host forwards them)
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.setActionHandler('play', toggle);
      navigator.mediaSession.setActionHandler('pause', toggle);
      navigator.mediaSession.setActionHandler('nexttrack', () => step(1));
      navigator.mediaSession.setActionHandler('previoustrack', () => step(-1));
    } catch (e) {}
  }

  /* ---------- init ---------- */
  applyTheme();
  load(false);
  applyLang();
  startMeter();
})();
