(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const KEY = 'musicDucker.v2';
  const OLD_KEY = 'musicDucker.v1';
  const AUDIO_RE = /\.(mp3|wav|m4a|aac|ogg|oga|flac|opus)$/i;

  /* ---------- settings ---------- */
  const S = {
    vol: 70, duckOn: true, duckLevel: 15, attack: 150, release: 700, hold: 700,
    sens: 60, folder: '', last: '', shuffle: false, loop: false,
    favOnly: false, favs: [], advOpen: false
  };
  try {
    const old = JSON.parse(localStorage.getItem(OLD_KEY) || '{}');
    delete old.hold; delete old.mode;
    Object.assign(S, old, JSON.parse(localStorage.getItem(KEY) || '{}'));
  } catch (e) {}
  const favs = new Set(S.favs);
  const save = () => {
    S.favs = Array.from(favs);
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {}
  };

  /* ---------- helpers ---------- */
  const clamp = (v, a, b) => Math.min(b === undefined ? 1 : b, Math.max(a === undefined ? 0 : a, v));
  const base = (p) => p.split(/[\\/]/).pop();
  const noExt = (n) => n.replace(/\.[^.]+$/, '');
  const fmt = (s) => {
    if (!isFinite(s)) return '0:00';
    s = Math.floor(s);
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  };
  const toUrl = (p) => {
    p = p.replace(/\\/g, '/');
    if (p[0] !== '/') p = '/' + p;
    return 'file://' + encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F');
  };
  const paint = (el) => {
    const min = +el.min || 0, max = +el.max || 100;
    el.style.setProperty('--p', ((el.value - min) / (max - min)) * 100 + '%');
  };
  let toastTimer = 0;
  const toast = (msg) => {
    const t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
  };

  /* ---------- file system ---------- */
  let nodeFs = null, nodePath = null;
  try { if (window.require) { nodeFs = window.require('fs'); nodePath = window.require('path'); } } catch (e) {}

  const natCmp = (a, b) => base(a).localeCompare(base(b), undefined, { numeric: true, sensitivity: 'base' });

  function scan(dir) {
    const out = [];
    if (nodeFs && nodePath) {
      const walk = (d, depth) => {
        let names;
        try { names = nodeFs.readdirSync(d); } catch (e) { return; }
        names.forEach((n) => {
          const p = nodePath.join(d, n);
          if (AUDIO_RE.test(n)) { out.push(p); return; }
          if (depth < 3 && n[0] !== '.') {
            try { if (nodeFs.statSync(p).isDirectory()) walk(p, depth + 1); } catch (e) {}
          }
        });
      };
      walk(dir, 0);
    } else if (window.cep && window.cep.fs) {
      const r = window.cep.fs.readdir(dir);
      if (!r.err) r.data.forEach((n) => { if (AUDIO_RE.test(n)) out.push(dir.replace(/[\\/]$/, '') + '/' + n); });
    }
    return out.sort(natCmp);
  }

  /* ---------- library state ---------- */
  let tracks = [];       // {path, name}
  let view = [];         // indexes into tracks (after filter)
  let cur = -1;

  function load(keepCurrent) {
    if (!S.folder) { tracks = []; renderList(); return; }
    tracks = scan(S.folder).map((p) => ({ path: p, name: noExt(base(p)) }));
    $('folderName').textContent = base(S.folder) || S.folder;
    $('folderName').title = S.folder;
    if (keepCurrent && cur >= 0) {
      cur = tracks.findIndex((t) => t.path === S.last);
    } else {
      cur = tracks.findIndex((t) => t.path === S.last);
      if (cur >= 0) { audio.src = toUrl(tracks[cur].path); }
    }
    renderList();
    updateNow();
    if (!tracks.length) toast('تو این پوشه آهنگی پیدا نشد');
  }

  function setFolder(p) {
    S.folder = p; S.last = ''; cur = -1; audio.pause(); audio.removeAttribute('src');
    save(); load(false);
  }

  function pickFolder() {
    try {
      const r = window.cep.fs.showOpenDialogEx(false, true, 'پوشه آهنگ‌ها رو انتخاب کن', S.folder || '', []);
      if (r && !r.err && r.data && r.data[0]) setFolder(r.data[0]);
    } catch (e) {
      toast('دیالوگ باز نشد — پوشه رو بکش بنداز رو پنل');
    }
  }

  function renderList() {
    const q = $('search').value.trim().toLowerCase();
    view = [];
    tracks.forEach((t, i) => {
      if (S.favOnly && !favs.has(t.path)) return;
      if (q && t.name.toLowerCase().indexOf(q) < 0) return;
      view.push(i);
    });
    const ul = $('list');
    const frag = document.createDocumentFragment();
    view.forEach((i, n) => {
      const li = document.createElement('li');
      li.dataset.i = i;
      if (i === cur) li.className = 'cur';
      li.innerHTML = '<span class="n"></span><span class="t" dir="auto"></span><button class="st" data-fav="1">★</button>';
      li.children[0].textContent = i === cur && !audio.paused ? '♪' : n + 1;
      li.children[1].textContent = tracks[i].name;
      li.children[1].title = tracks[i].name;
      if (favs.has(tracks[i].path)) li.children[2].classList.add('on');
      frag.appendChild(li);
    });
    ul.innerHTML = '';
    ul.appendChild(frag);
    $('empty').style.display = tracks.length ? 'none' : '';
    $('count').textContent = tracks.length ? (view.length === tracks.length ? tracks.length + ' آهنگ' : view.length + ' از ' + tracks.length + ' آهنگ') : '';
  }

  function markPlaying() {
    const lis = $('list').children;
    for (let k = 0; k < lis.length; k++) {
      const li = lis[k], i = +li.dataset.i;
      li.classList.toggle('cur', i === cur);
      li.children[0].textContent = i === cur && !audio.paused ? '♪' : k + 1;
    }
  }

  /* ---------- player ---------- */
  const audio = new Audio();
  audio.preload = 'metadata';
  let errStreak = 0;

  function updateNow() {
    const t = cur >= 0 ? tracks[cur] : null;
    $('title').textContent = t ? t.name : 'یه آهنگ انتخاب کن';
    $('sub').textContent = t ? base(t.path).split('.').pop().toUpperCase() + ' · ' + (cur + 1) + ' / ' + tracks.length : '—';
    $('btnFav').classList.toggle('on', !!t && favs.has(t.path));
    $('btnFav').textContent = t && favs.has(t.path) ? '★' : '☆';
    if ('mediaSession' in navigator && t) {
      try { navigator.mediaSession.metadata = new window.MediaMetadata({ title: t.name, artist: 'AE Music Player' }); } catch (e) {}
    }
  }

  function playIndex(i) {
    if (i < 0 || i >= tracks.length) return;
    cur = i;
    S.last = tracks[i].path; save();
    audio.src = toUrl(tracks[i].path);
    const p = audio.play();
    if (p && p.catch) p.catch(() => {});
    updateNow(); markPlaying();
  }

  function toggle() {
    if (cur < 0) {
      if (!view.length) { toast('اول پوشه آهنگ رو انتخاب کن'); return; }
      playIndex(view[0]); return;
    }
    if (audio.paused) { const p = audio.play(); if (p && p.catch) p.catch(() => {}); } else audio.pause();
  }

  function step(dir) {
    if (!view.length) return;
    let next;
    if (S.shuffle && view.length > 1) {
      do { next = view[Math.floor(Math.random() * view.length)]; } while (next === cur);
    } else {
      let pos = view.indexOf(cur);
      pos = pos < 0 ? 0 : (pos + dir + view.length) % view.length;
      next = view[pos];
    }
    playIndex(next);
  }

  audio.addEventListener('play', () => { $('btnPlay').textContent = '⏸'; $('eq').classList.add('on'); markPlaying(); errStreak = 0; });
  audio.addEventListener('pause', () => { $('btnPlay').textContent = '▶'; $('eq').classList.remove('on'); markPlaying(); });
  audio.addEventListener('ended', () => step(1));
  audio.addEventListener('loadedmetadata', () => { $('tDur').textContent = fmt(audio.duration); });
  audio.addEventListener('error', () => {
    if (cur < 0) return;
    toast('این فایل پخش نشد، رد میشم');
    if (++errStreak < Math.max(3, Math.min(tracks.length, 8))) setTimeout(() => step(1), 500);
  });

  let seeking = false;
  audio.addEventListener('timeupdate', () => {
    $('tCur').textContent = fmt(audio.currentTime);
    if (!seeking && audio.duration) {
      $('seek').value = (audio.currentTime / audio.duration) * 1000;
      paint($('seek'));
    }
  });
  $('seek').addEventListener('input', () => { seeking = true; paint($('seek')); if (audio.duration) $('tCur').textContent = fmt(($('seek').value / 1000) * audio.duration); });
  $('seek').addEventListener('change', () => { if (audio.duration) audio.currentTime = ($('seek').value / 1000) * audio.duration; seeking = false; });

  /* ---------- volume + ducking ---------- */
  let autoDuck = false, holdManual = false;
  let meterState = 'init'; // init | ready | error | unsupported
  let gain = S.vol / 100, fade = null, fadeTimer = 0;

  const isDucked = () => holdManual || (S.duckOn && autoDuck);
  const targetGain = () => (isDucked() ? (S.vol / 100) * (S.duckLevel / 100) : S.vol / 100);

  function fadeStep() {
    if (!fade) { clearInterval(fadeTimer); fadeTimer = 0; return; }
    const k = clamp((performance.now() - fade.t0) / Math.max(1, fade.dur));
    const e = fade.to < fade.from ? 1 - Math.pow(1 - k, 2) : k * k * (3 - 2 * k);
    gain = fade.from + (fade.to - fade.from) * e;
    audio.volume = clamp(gain);
    if (k >= 1) { fade = null; clearInterval(fadeTimer); fadeTimer = 0; }
  }

  function retarget() {
    const to = targetGain();
    if (Math.abs(to - gain) < 0.001) { fade = null; return; }
    fade = { from: gain, to: to, t0: performance.now(), dur: to < gain ? S.attack : S.release };
    if (!fadeTimer) fadeTimer = setInterval(fadeStep, 16);
    updatePill();
  }

  function updatePill() {
    let cls = 'ok', txt = 'آماده';
    if (meterState === 'unsupported') { cls = ''; txt = 'دَک خودکار: فقط ویندوز'; }
    else if (meterState === 'error') { cls = ''; txt = 'خطا تو تشخیص صدا'; }
    else if (meterState === 'init') { cls = ''; txt = 'در حال راه‌اندازی...'; }
    else if (!S.duckOn && !holdManual) { cls = ''; txt = 'دَک خاموشه'; }
    if (isDucked()) { cls = 'duck'; txt = 'صدا کم شد'; }
    $('pill').className = 'pill ' + cls;
    $('pill').textContent = txt;
    $('eq').classList.toggle('duck', isDucked());
  }

  function setAuto(v) {
    if (v === autoDuck) return;
    autoDuck = v;
    retarget(); updatePill();
  }

  /* ---------- After Effects audio detection (Windows) ----------
     A small PowerShell helper reads the Windows mixer peak level of AfterFX.exe.
     Nothing is sent to After Effects, so playback is never interrupted. */
  const thrOf = () => 0.02 * Math.pow(1 - S.sens / 100, 2) + 0.0005;
  const dbPct = (v) => clamp((20 * Math.log10(Math.max(v, 1e-5)) + 60) / 60);
  const placeThr = () => { $('thrMark').style.left = dbPct(thrOf()) * 100 + '%'; };
  let lastActive = -1e9, lastTxt = '';

  function setLvlText(t) { if (t !== lastTxt) { lastTxt = t; $('lvlTxt').textContent = t; } }

  function onPeak(peak) {
    const now = performance.now();
    const hot = peak > thrOf();
    $('lvl').style.width = dbPct(peak) * 100 + '%';
    $('lvl').parentNode.classList.toggle('hot', hot);
    if (hot) lastActive = now;
    setLvlText(hot ? 'صدای افترافکت شناسایی شد' : 'صدایی از افترافکت نمیاد');
    setAuto(S.duckOn && now - lastActive < S.hold);
  }

  function extDir() {
    try {
      if (window.__adobe_cep__ && window.__adobe_cep__.getSystemPath) {
        const u = window.__adobe_cep__.getSystemPath('extension');
        if (u) return decodeURI(u).replace(/^file:\/\/\//, '').replace(/\\/g, '/');
      }
    } catch (e) {}
    try { if (typeof __dirname === 'string') return __dirname.replace(/\\/g, '/'); } catch (e) {}
    return decodeURI(location.pathname.replace(/^\//, '')).replace(/\/index\.html$/, '');
  }

  let meterProc = null, restarts = 0, errCount = 0;

  function killMeter() {
    if (meterProc) { try { meterProc.kill(); } catch (e) {} meterProc = null; }
  }

  function failMeter(msg) {
    meterState = 'error';
    setLvlText(msg);
    setAuto(false); updatePill();
  }

  function handleLine(line) {
    if (!line) return;
    const tag = line[0], rest = line.slice(2);
    if (tag === 'P') {
      if (meterState !== 'ready') { meterState = 'ready'; restarts = 0; updatePill(); }
      errCount = 0;
      onPeak(parseFloat(rest) || 0);
    } else if (tag === 'R') {
      meterState = 'ready'; updatePill(); setLvlText('منتظر صدای افترافکت...');
    } else if (tag === 'E') {
      if (rest.indexOf('compile') === 0) { failMeter('خطای راه‌اندازی: ' + rest.slice(0, 80)); toast('تشخیص صدا راه نیفتاد'); }
      else if (++errCount > 20) failMeter('خطا: ' + rest.slice(0, 80));
    }
  }

  function startMeter() {
    let os = null, cp = null;
    try { os = window.require('os'); cp = window.require('child_process'); } catch (e) {}
    if (!cp || !os) { meterState = 'unsupported'; setLvlText('نود فعال نیست (فقط دَک دستی)'); updatePill(); return; }
    if (os.platform() !== 'win32') { meterState = 'unsupported'; setLvlText('تشخیص خودکار فقط ویندوز — دَک دستی هست'); updatePill(); return; }

    killMeter();
    meterState = 'init'; updatePill(); setLvlText('در حال راه‌اندازی...');
    const script = extDir() + '/bin/audio-meter.ps1';
    const pid = (window.process && window.process.pid) || 0;
    let proc;
    try {
      proc = cp.spawn('powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-ParentPid', String(pid)],
        { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) { failMeter('پاورشل اجرا نشد'); return; }
    meterProc = proc;

    let buf = '', errBuf = '';
    proc.stdout.on('data', (d) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); handleLine(line); }
    });
    proc.stderr.on('data', (d) => { errBuf += d.toString(); });
    proc.on('error', () => failMeter('پاورشل پیدا نشد'));
    proc.on('exit', () => {
      if (meterProc !== proc) return;
      meterProc = null;
      if (meterState === 'error') return;
      if (restarts++ < 3) setTimeout(startMeter, 1500);
      else failMeter(errBuf ? 'تشخیص صدا متوقف شد: ' + errBuf.trim().slice(0, 60) : 'تشخیص صدا متوقف شد');
    });
  }
  window.addEventListener('beforeunload', killMeter);
  window.addEventListener('unload', killMeter);

  /* ---------- UI wiring ---------- */
  $('btnPlay').addEventListener('click', toggle);
  $('btnNext').addEventListener('click', () => step(1));
  $('btnPrev').addEventListener('click', () => { if (audio.currentTime > 3) audio.currentTime = 0; else step(-1); });

  const setToggle = (id, key, onChange) => {
    const b = $(id);
    b.classList.toggle('on', !!S[key]);
    b.addEventListener('click', () => { S[key] = !S[key]; b.classList.toggle('on', S[key]); save(); if (onChange) onChange(); });
  };
  setToggle('btnShuffle', 'shuffle');
  setToggle('btnLoop', 'loop', () => { audio.loop = S.loop; });
  setToggle('btnFavOnly', 'favOnly', renderList);
  audio.loop = !!S.loop;

  $('btnFav').addEventListener('click', () => {
    if (cur < 0) return;
    const p = tracks[cur].path;
    favs.has(p) ? favs.delete(p) : favs.add(p);
    save(); updateNow(); renderList();
  });

  $('list').addEventListener('click', (e) => {
    const li = e.target.closest('li'); if (!li) return;
    const i = +li.dataset.i;
    if (e.target.dataset.fav) {
      const p = tracks[i].path;
      favs.has(p) ? favs.delete(p) : favs.add(p);
      save(); updateNow(); renderList();
      return;
    }
    if (i === cur) toggle(); else playIndex(i);
  });

  $('search').addEventListener('input', renderList);
  $('btnFolder').addEventListener('click', pickFolder);
  $('btnRescan').addEventListener('click', () => { load(true); toast('لیست آپدیت شد'); });

  // volume
  const vol = $('vol');
  vol.value = S.vol; $('volVal').textContent = S.vol + '%'; paint(vol);
  vol.addEventListener('input', () => {
    S.vol = +vol.value; $('volVal').textContent = S.vol + '%'; paint(vol); save();
    if (isDucked()) retarget(); else { fade = null; gain = S.vol / 100; audio.volume = clamp(gain); }
  });
  audio.volume = clamp(gain);

  // duck settings
  [['duckLevel', '%'], ['attack', 'ms'], ['release', 'ms'], ['hold', 'ms']].forEach((a) => {
    const id = a[0], suf = a[1], el = $(id);
    el.value = S[id]; $(id + 'Val').textContent = S[id] + suf; paint(el);
    el.addEventListener('input', () => {
      S[id] = +el.value; $(id + 'Val').textContent = el.value + suf; paint(el); save();
      if (id === 'duckLevel') retarget();
    });
  });

  $('duckOn').checked = !!S.duckOn;
  $('duckOn').addEventListener('change', () => { S.duckOn = $('duckOn').checked; save(); if (!S.duckOn) setAuto(false); retarget(); updatePill(); });

  const sens = $('sens');
  sens.value = S.sens; $('sensVal').textContent = S.sens; paint(sens); placeThr();
  sens.addEventListener('input', () => { S.sens = +sens.value; $('sensVal').textContent = S.sens; paint(sens); save(); placeThr(); });

  $('btnHold').addEventListener('click', () => {
    holdManual = !holdManual;
    $('btnHold').classList.toggle('on', holdManual);
    $('btnHold').textContent = holdManual ? '🔊 آزاد کن' : '🔇 دَک دستی';
    retarget(); updatePill();
  });

  $('adv').classList.toggle('hidden', !S.advOpen);
  $('btnAdv').addEventListener('click', () => { S.advOpen = !S.advOpen; $('adv').classList.toggle('hidden', !S.advOpen); save(); });

  paint($('seek'));

  // drag & drop a folder (or a file -> its folder)
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => {
    e.preventDefault();
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f || !f.path) { toast('برای درگ‌ودراپ دسترسی نود لازمه — از دکمه پوشه استفاده کن'); return; }
    let dir = f.path;
    try { if (nodeFs && !nodeFs.statSync(dir).isDirectory()) dir = nodePath.dirname(dir); } catch (err) {}
    setFolder(dir);
  });

  // media keys (if the host forwards them)
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.setActionHandler('play', toggle);
      navigator.mediaSession.setActionHandler('pause', toggle);
      navigator.mediaSession.setActionHandler('nexttrack', () => step(1));
      navigator.mediaSession.setActionHandler('previoustrack', () => step(-1));
    } catch (e) {}
  }

  /* ---------- init ---------- */
  load(false);
  updateNow();
  updatePill();
  startMeter();
})();
